namespace CleanArchitecture.Application.Users.LoginUser;

public record LoginUserRequest(string Email, string Password);