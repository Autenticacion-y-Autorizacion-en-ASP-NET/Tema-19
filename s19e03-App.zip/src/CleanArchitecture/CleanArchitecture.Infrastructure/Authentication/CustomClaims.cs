namespace CleanArchitecture.Infrastructure.Authentication;

public static class CustomClaims
{

    internal const string Permissions = "permissions";

}