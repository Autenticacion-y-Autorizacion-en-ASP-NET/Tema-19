namespace CleanArchitecture.Domain.Vehiculos;


public record Direccion
(
    string Pais,
    string Departamento,
    string Provincia,
    string Ciudad,
    string Calle
);