namespace CleanArchitecture.Domain.Users;

public record Email(string Value);